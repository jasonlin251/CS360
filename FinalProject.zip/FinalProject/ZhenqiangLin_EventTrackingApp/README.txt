Zhenqiang Lin - Event Tracking App UI
CS 360 Project Two

This Android Studio project includes:
1. Login/Create Account screen
2. Upcoming Events database grid screen
3. Add Event screen
4. SMS Permission screen
5. SEND_SMS permission and telephony feature declarations in AndroidManifest.xml
6. Consistent visual theme, clear focus order, grouped controls, and fade transitions

Open the folder in Android Studio, allow Gradle Sync to finish, select the app configuration and an emulator, and click Run.

The sample navigation and permission prompt are included so each UI screen can be reviewed. Database persistence and actual SMS sending are intentionally not implemented because those belong to Project Three.
